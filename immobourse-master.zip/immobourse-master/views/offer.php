<h1>Offre numéro <?= $offer->id ?></h1>
<p>
    Ville : <?= $offer->city ?>
</p>
<p>
    Prix : <?= $offer->price ?>€
</p>
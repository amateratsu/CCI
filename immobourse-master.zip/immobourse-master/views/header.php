<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon super site</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<body>
<h3>Mon super site</h3>
<a href="index.php?page=accueil">Accueil</a> - <a href="index.php?page=list">Liste</a>
<hr>
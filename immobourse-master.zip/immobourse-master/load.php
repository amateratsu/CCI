<?php
// controlleurs
include 'controllers/Controller.php';
include 'controllers/AccueilController.php';
include 'controllers/OffersController.php';

// modèles
include 'models/Model.php';
include 'models/OffersModel.php';
include 'models/AffiliatesModel.php';

// router
include 'Router.php';